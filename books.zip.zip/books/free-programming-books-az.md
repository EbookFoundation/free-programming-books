### Index

* [C](#c)
* [HTML](#html)
* [Linux](#linux)
  


### C

* [C Proqramlaşdırma Dili](https://web.archive.org/web/20241214000729/https://ilkaddimlar.com/ders/c-proqramlasdirma-dili) ( :card_file_box: archived)


### HTML

* [HTML](https://web.archive.org/web/20241214005042/https://ilkaddimlar.com/ders/html) ( :card_file_box: archived)


### Linux

* [Linux](https://web.archive.org/web/20241214095624/https://ilkaddimlar.com/ders/linux) ( :card_file_box: archived)



