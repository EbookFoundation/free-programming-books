### Index

* [0 - Meta-Lists](#0---meta-lists)
* [C](#c)
* [Python](#python)


### 0 - Meta-Lists

* [Books - Telugu](https://sites.google.com/nptel.iitm.ac.in/translated-ebook/telugu)


### <a id="c"></a>C

* [Introduction to C \| Telugu](https://www.computerintelugu.com/2012/11/cmenu.html) - Sivanaadh Baazi Karampudi


### <a id="python"></a>Python

* [Python Course in Telugu: 30 days challenge](https://www.youtube.com/playlist?list=PLNgoFk5SYUglQOaXSY8lAlPXmK6tQBHaw) - Vamsi Bhavani
